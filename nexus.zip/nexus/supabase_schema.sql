-- ============================================================================
-- NEXUS — Esquema do banco de dados (Supabase / Postgres)
-- ============================================================================
-- Como usar:
-- 1. Abra seu projeto em https://app.supabase.com
-- 2. Vá em "SQL Editor" → "New query"
-- 3. Cole este arquivo inteiro e clique em "Run"
-- 4. Confirme que as tabelas apareceram em "Table Editor"
--
-- Este script é seguro para rodar mais de uma vez (usa IF NOT EXISTS / OR REPLACE).
-- ============================================================================

-- Extensão usada para gerar UUIDs
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- Tabela: profiles
-- Um perfil é criado automaticamente para cada novo usuário autenticado.
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null default '',
  monthly_goal numeric not null default 5000,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Usuários veem o próprio perfil" on public.profiles;
create policy "Usuários veem o próprio perfil"
  on public.profiles for select
  using (auth.uid() = id);

drop policy if exists "Usuários atualizam o próprio perfil" on public.profiles;
create policy "Usuários atualizam o próprio perfil"
  on public.profiles for update
  using (auth.uid() = id);

drop policy if exists "Usuários inserem o próprio perfil" on public.profiles;
create policy "Usuários inserem o próprio perfil"
  on public.profiles for insert
  with check (auth.uid() = id);

-- Função + gatilho: cria automaticamente um profile quando um usuário se cadastra
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ----------------------------------------------------------------------------
-- Tabela: projects
-- Cada projeto é um produto digital (ebook) com seu conteúdo, pesquisa e plano.
-- O conteúdo é guardado em colunas jsonb para manter o schema simples e flexível.
-- ----------------------------------------------------------------------------
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  name text not null,
  niche text not null,
  objective text not null,
  pages integer not null default 30,
  language text not null default 'Português',
  cover_url text,
  ebook jsonb not null,
  research jsonb not null,
  outreach jsonb not null,
  milestones jsonb not null default '{
    "ebookCreated": false,
    "researchCompleted": false,
    "messagesReady": false,
    "communitiesAnalyzed": false,
    "firstPromoDone": false,
    "firstSaleRegistered": false
  }'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists projects_user_id_idx on public.projects (user_id);

alter table public.projects enable row level security;

drop policy if exists "Usuários veem os próprios projetos" on public.projects;
create policy "Usuários veem os próprios projetos"
  on public.projects for select
  using (auth.uid() = user_id);

drop policy if exists "Usuários criam os próprios projetos" on public.projects;
create policy "Usuários criam os próprios projetos"
  on public.projects for insert
  with check (auth.uid() = user_id);

drop policy if exists "Usuários atualizam os próprios projetos" on public.projects;
create policy "Usuários atualizam os próprios projetos"
  on public.projects for update
  using (auth.uid() = user_id);

drop policy if exists "Usuários removem os próprios projetos" on public.projects;
create policy "Usuários removem os próprios projetos"
  on public.projects for delete
  using (auth.uid() = user_id);

-- ----------------------------------------------------------------------------
-- Tabela: sales
-- Registros manuais de vendas vinculados a um projeto.
-- ----------------------------------------------------------------------------
create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  project_id uuid not null references public.projects (id) on delete cascade,
  value numeric not null check (value > 0),
  sale_date date not null default current_date,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists sales_user_id_idx on public.sales (user_id);
create index if not exists sales_project_id_idx on public.sales (project_id);

alter table public.sales enable row level security;

drop policy if exists "Usuários veem as próprias vendas" on public.sales;
create policy "Usuários veem as próprias vendas"
  on public.sales for select
  using (auth.uid() = user_id);

drop policy if exists "Usuários criam as próprias vendas" on public.sales;
create policy "Usuários criam as próprias vendas"
  on public.sales for insert
  with check (auth.uid() = user_id);

drop policy if exists "Usuários removem as próprias vendas" on public.sales;
create policy "Usuários removem as próprias vendas"
  on public.sales for delete
  using (auth.uid() = user_id);

-- ============================================================================
-- Fim do script. Suas tabelas, políticas de segurança (RLS) e gatilhos
-- já estão prontos para uso pelo app NEXUS.
-- ============================================================================
