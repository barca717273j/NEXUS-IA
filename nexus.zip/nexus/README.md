# Nexus

Plataforma para estruturar produtos digitais (ebooks): gera uma estrutura inicial de
conteúdo, pesquisa de público e plano de divulgação, e acompanha vendas — com login real,
banco de dados real e exportação de PDF real.

## O que mudou na reformulação

- **Autenticação real** com Supabase (e-mail/senha), substituindo o login decorativo que existia antes.
- **Dados reais no banco** — projetos, pesquisa de público e vendas ficam salvos no Postgres do Supabase, por usuário, com RLS (Row Level Security), em vez de ficar apenas no navegador.
- **Geração honesta de conteúdo** — a estrutura de capítulos, pesquisa de avatar e plano de divulgação é montada instantaneamente a partir do nicho/objetivo informados. Não existe uma "IA" simulada com loading falso: o app é transparente sobre ser um gerador de estrutura editável, não um substituto para escrever o conteúdo final.
- **PDF real** — o botão de exportação gera um arquivo `.pdf` de verdade (texto selecionável, paginado), em vez de abrir o diálogo de impressão do navegador.
- **Módulo de divulgação revisado** — em vez de scripts genéricos de "post espontâneo" para grupos, a aba de Divulgação traz boas práticas reais por canal (redes sociais, comunidades, contato direto, e-mail) e modelos de mensagem editáveis, com aviso explícito contra postar sem personalizar.
- **Correções de bugs**: datas de vendas exibidas com um dia de diferença (problema de fuso horário ao converter string → `Date`), métricas com nomenclatura ambígua, e duplicação de lógica de geração de conteúdo.
- **Visual redesenhado** — paleta preto/vermelho mais sóbria, tipografia com serifa editorial para títulos, remoção de selos e badges de hype ("Premium", "Exclusivo") e de animações excessivas.

## Pré-requisitos

- Node.js 18 ou superior
- Uma conta gratuita no [Supabase](https://supabase.com)

## Configuração

### 1. Instalar dependências

```bash
npm install
```

### 2. Criar o banco de dados no Supabase

1. Crie um projeto em [supabase.com](https://supabase.com).
2. No painel do projeto, vá em **SQL Editor** → **New query**.
3. Cole todo o conteúdo do arquivo [`supabase_schema.sql`](./supabase_schema.sql) e clique em **Run**.
4. Confirme em **Table Editor** que as tabelas `profiles`, `projects` e `sales` foram criadas.

Esse script também configura as políticas de segurança (RLS) que garantem que cada usuário
só veja e edite os próprios dados, e um gatilho que cria automaticamente um perfil quando
alguém se cadastra.

### 3. Configurar as variáveis de ambiente

Copie o arquivo de exemplo:

```bash
cp .env.example .env.local
```

Em **Project Settings → API** no painel do Supabase, copie a **Project URL** e a **anon
public key**, e preencha o `.env.local`:

```
VITE_SUPABASE_URL="https://seu-projeto.supabase.co"
VITE_SUPABASE_ANON_KEY="sua-chave-anon"
```

### 4. Rodar o projeto

```bash
npm run dev
```

O app abre em `http://localhost:3000`. Crie uma conta pela própria tela de cadastro — não há
usuário fixo de demonstração.

## Build de produção

```bash
npm run build
npm run preview
```

## Estrutura do projeto

```
src/
  components/        Componentes de UI
  data/
    generator.ts      Motor de geração de estrutura de conteúdo (determinístico)
    projects.ts        Camada de acesso a dados (Supabase: projetos e vendas)
    pdfExport.ts        Exportação real de PDF (jsPDF)
  hooks/
    useAuth.ts          Autenticação e perfil do usuário
  lib/
    supabase.ts         Cliente Supabase
  types.ts              Tipos de domínio
supabase_schema.sql      Schema do banco (tabelas, índices, RLS, gatilhos)
```

## Aviso importante sobre o conteúdo gerado

O gerador de estrutura é uma ferramenta de produtividade, não um redator automático: ele monta
um esqueleto coerente de capítulos, perguntas de pesquisa de público e modelos de mensagem,
mas o texto final — exemplos, dados, provas e a voz do material — precisa ser escrito por você.
Trate a saída como um rascunho de primeira versão.
