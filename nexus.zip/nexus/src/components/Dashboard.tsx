import { motion } from "framer-motion";
import { Plus, ChevronRight, Layers } from "lucide-react";
import { Project } from "../types";
import MetricCards from "./MetricCards";
import SalesChart from "./SalesChart";

interface DashboardProps {
  projects: Project[];
  monthlyGoal: number;
  onCreateNew: () => void;
  onSelectProject: (id: string) => void;
}

export default function Dashboard({ projects, monthlyGoal, onCreateNew, onSelectProject }: DashboardProps) {
  const allSales = projects.flatMap((p) => p.sales);
  const totalRevenue = allSales.reduce((sum, s) => sum + s.value, 0);
  const projectsWithoutSales = projects.filter((p) => p.sales.length === 0).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="space-y-7"
    >
      {/* Bloco de ação principal */}
      <div className="bg-surface-1 border border-border p-7 sm:p-8 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand/40 to-transparent" />
        <div className="max-w-xl relative z-10">
          <h2 className="font-serif text-2xl font-semibold text-text-primary tracking-tight mb-2.5">
            Estruture seu próximo produto digital
          </h2>
          <p className="text-sm text-text-secondary leading-relaxed mb-6">
            Descreva o nicho e o objetivo, e o Nexus monta uma estrutura editável de conteúdo,
            pesquisa de público e plano de divulgação para você completar.
          </p>
          <button
            onClick={onCreateNew}
            className="inline-flex items-center gap-2.5 py-3 px-5 rounded-xl bg-brand hover:bg-brand-hover text-white text-sm font-medium transition-colors cursor-pointer"
          >
            <Plus size={16} />
            <span>Criar novo projeto</span>
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <MetricCards
        totalProjects={projects.length}
        projectsWithoutSales={projectsWithoutSales}
        totalSalesCount={allSales.length}
        totalRevenue={totalRevenue}
        monthlyGoal={monthlyGoal}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8">
          <SalesChart sales={allSales} />
        </div>

        <div className="lg:col-span-4 bg-surface-1 border border-border p-6 rounded-xl flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-medium text-text-secondary mb-4 flex items-center gap-2">
              <Layers size={14} className="text-text-muted" />
              Seus projetos ({projects.length})
            </h4>

            {projects.length === 0 ? (
              <p className="text-sm text-text-muted">Você ainda não criou nenhum projeto.</p>
            ) : (
              <div className="space-y-2 max-h-[220px] overflow-y-auto">
                {projects.map((proj) => {
                  const revenue = proj.sales.reduce((sum, s) => sum + s.value, 0);
                  return (
                    <button
                      key={proj.id}
                      onClick={() => onSelectProject(proj.id)}
                      className="w-full text-left p-3 rounded-lg border border-border bg-surface-0 hover:border-border-strong transition-colors cursor-pointer flex items-center justify-between gap-3"
                    >
                      <div className="truncate flex-1">
                        <p className="text-sm font-medium text-text-primary truncate">{proj.ebook.title}</p>
                        <p className="text-xs text-text-muted truncate mt-0.5">{proj.niche}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-mono font-medium text-brand">R$ {revenue.toLocaleString("pt-BR")}</p>
                        <p className="text-xs text-text-muted mt-0.5">{proj.sales.length} vendas</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {projects.length > 0 && (
            <p className="text-xs text-text-muted pt-4 mt-4 border-t border-border leading-relaxed">
              Clique em um projeto para abrir a biblioteca de conteúdo e registrar vendas.
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
