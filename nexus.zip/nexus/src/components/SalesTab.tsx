import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { DollarSign, TrendingUp, Trash2 } from "lucide-react";
import { Project } from "../types";

interface SalesTabProps {
  project: Project;
  onRegisterSale: (sale: { value: number; date: string; note?: string }) => Promise<void>;
  onDeleteSale: (saleId: string) => Promise<void>;
}

function formatDate(isoDate: string): string {
  const [year, month, day] = isoDate.split("-").map(Number);
  if (!year || !month || !day) return isoDate;
  return `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}/${year}`;
}

export default function SalesTab({ project, onRegisterSale, onDeleteSale }: SalesTabProps) {
  const [value, setValue] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [note, setNote] = useState("");
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(value);
    if (isNaN(parsed) || parsed <= 0) return;

    setSubmitting(true);
    try {
      await onRegisterSale({ value: parsed, date, note: note.trim() || undefined });
      setValue("");
      setNote("");
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2500);
    } finally {
      setSubmitting(false);
    }
  };

  const total = project.sales.reduce((sum, s) => sum + s.value, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="grid grid-cols-1 lg:grid-cols-12 gap-6"
    >
      <div className="lg:col-span-5 bg-surface-1 border border-border p-6 rounded-xl self-start">
        <h4 className="text-sm font-medium text-text-primary mb-4 flex items-center gap-2">
          <DollarSign size={15} className="text-brand" />
          Registrar venda
        </h4>

        {success && (
          <div className="mb-4 p-3 bg-success-soft border border-success/30 rounded-lg text-success text-sm">
            Venda registrada.
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-text-secondary">Valor (R$)</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="Ex.: 47.00"
              className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-text-secondary">Data</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary outline-none transition-colors"
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-text-secondary">Observação (opcional)</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ex.: Venda via indicação"
              className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 bg-brand hover:bg-brand-hover disabled:opacity-60 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
          >
            {submitting ? "Registrando..." : "Registrar venda"}
          </button>
        </form>
      </div>

      <div className="lg:col-span-7 bg-surface-1 border border-border p-6 rounded-xl flex flex-col justify-between min-h-[280px]">
        <div>
          <h4 className="text-sm font-medium text-text-primary mb-4 flex items-center gap-2">
            <TrendingUp size={15} className="text-brand" />
            Histórico deste projeto
          </h4>

          {project.sales.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <DollarSign size={20} className="text-text-muted mb-3" />
              <p className="text-sm font-medium text-text-secondary">Nenhuma venda registrada</p>
              <p className="text-xs text-text-muted mt-1 max-w-xs">
                Use o formulário ao lado para registrar manualmente cada venda realizada.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[300px] overflow-y-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-text-muted text-xs font-medium border-b border-border">
                  <tr>
                    <th className="py-2 px-2">Data</th>
                    <th className="py-2 px-2">Valor</th>
                    <th className="py-2 px-2">Observação</th>
                    <th className="py-2 px-2 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {project.sales.map((sale) => (
                    <tr key={sale.id}>
                      <td className="py-2.5 px-2 font-mono text-xs text-text-secondary">{formatDate(sale.date)}</td>
                      <td className="py-2.5 px-2 text-brand font-medium">R$ {sale.value.toLocaleString("pt-BR")}</td>
                      <td className="py-2.5 px-2 text-text-secondary truncate max-w-[160px]">{sale.note || "—"}</td>
                      <td className="py-2.5 px-2 text-right">
                        <button
                          onClick={() => onDeleteSale(sale.id)}
                          className="p-1 text-text-muted hover:text-brand rounded transition-colors cursor-pointer"
                          title="Remover"
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {project.sales.length > 0 && (
          <div className="border-t border-border pt-4 mt-4 flex justify-between items-center text-xs text-text-muted font-mono">
            <span>{project.sales.length} {project.sales.length === 1 ? "transação" : "transações"}</span>
            <span className="font-semibold text-text-primary">R$ {total.toLocaleString("pt-BR")}</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
