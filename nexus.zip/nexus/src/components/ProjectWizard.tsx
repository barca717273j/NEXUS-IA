import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { BookOpen, Globe, Image as ImageIcon, ArrowRight, Info } from "lucide-react";

interface ProjectWizardProps {
  onGenerate: (
    name: string,
    niche: string,
    objective: string,
    pages: number,
    language: string,
    coverUrl?: string
  ) => Promise<void>;
  isSubmitting: boolean;
}

export default function ProjectWizard({ onGenerate, isSubmitting }: ProjectWizardProps) {
  const [name, setName] = useState("");
  const [niche, setNiche] = useState("");
  const [objective, setObjective] = useState("");
  const [pages, setPages] = useState(30);
  const [language, setLanguage] = useState("Português");
  const [coverOption, setCoverOption] = useState<"auto" | "custom">("auto");
  const [customCoverUrl, setCustomCoverUrl] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !niche.trim() || !objective.trim()) {
      setError("Preencha nome, nicho e objetivo para continuar.");
      return;
    }
    setError("");
    await onGenerate(
      name.trim(),
      niche.trim(),
      objective.trim(),
      pages,
      language,
      coverOption === "custom" ? customCoverUrl.trim() : undefined
    );
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="bg-surface-1 border border-border p-6 sm:p-8 rounded-2xl">
        <div className="mb-7 pb-6 border-b border-border">
          <h2 className="font-serif text-xl font-semibold text-text-primary">
            Estruturar um novo produto digital
          </h2>
          <p className="text-sm text-text-secondary mt-2 leading-relaxed">
            Descreva o nicho e o objetivo do seu material. O Nexus monta uma estrutura inicial
            editável — capítulos, pesquisa de público e plano de divulgação — para você completar
            com seu próprio conteúdo.
          </p>
        </div>

        {error && (
          <div className="mb-5 p-3 bg-brand-soft border border-brand-border rounded-lg text-sm text-text-primary">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-medium text-text-secondary">
              Objetivo principal do material
            </label>
            <textarea
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              placeholder="Ex.: Ajudar pessoas a organizar as finanças pessoais e começar a investir do zero."
              rows={3}
              className="w-full px-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors resize-none"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary">Nome do produto</label>
              <div className="relative">
                <BookOpen size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex.: Plano de 30 Dias"
                  className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary">Nicho / categoria</label>
              <input
                type="text"
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                placeholder="Ex.: Finanças pessoais"
                className="w-full px-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary flex justify-between">
                <span>Páginas estimadas</span>
                <span className="text-brand font-mono">{pages}</span>
              </label>
              <input
                type="range"
                min={15}
                max={80}
                step={5}
                value={pages}
                onChange={(e) => setPages(Number(e.target.value))}
                className="w-full accent-brand cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary">Idioma</label>
              <div className="relative">
                <Globe size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary outline-none transition-colors cursor-pointer appearance-none"
                >
                  <option value="Português">Português (Brasil)</option>
                  <option value="Espanhol">Espanhol</option>
                  <option value="Inglês">Inglês</option>
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-medium text-text-secondary">Capa</label>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={() => setCoverOption("auto")}
                className={`flex-1 p-3.5 border text-left rounded-xl transition-colors cursor-pointer ${
                  coverOption === "auto" ? "border-brand bg-brand-soft" : "border-border bg-surface-2 hover:border-border-strong"
                }`}
              >
                <p className="text-sm font-medium text-text-primary mb-0.5">Capa sugerida</p>
                <p className="text-xs text-text-muted">Uma imagem de banco de imagens relacionada ao nicho.</p>
              </button>
              <button
                type="button"
                onClick={() => setCoverOption("custom")}
                className={`flex-1 p-3.5 border text-left rounded-xl transition-colors cursor-pointer ${
                  coverOption === "custom" ? "border-brand bg-brand-soft" : "border-border bg-surface-2 hover:border-border-strong"
                }`}
              >
                <p className="text-sm font-medium text-text-primary mb-0.5">Usar um link de imagem</p>
                <p className="text-xs text-text-muted">Cole a URL de uma imagem para usar como capa.</p>
              </button>
            </div>

            {coverOption === "custom" && (
              <div className="relative pt-1">
                <ImageIcon size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted mt-0.5" />
                <input
                  type="url"
                  value={customCoverUrl}
                  onChange={(e) => setCustomCoverUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
                />
              </div>
            )}
          </div>

          <div className="flex items-start gap-2.5 p-3.5 bg-surface-2 border border-border rounded-xl">
            <Info size={14} className="text-text-muted mt-0.5 shrink-0" />
            <p className="text-xs text-text-secondary leading-relaxed">
              O conteúdo gerado é um rascunho estrutural com capítulos, pesquisa de público e plano
              de divulgação. Revise e reescreva cada seção com sua própria experiência antes de publicar.
            </p>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-brand hover:bg-brand-hover disabled:opacity-60 text-white text-sm font-medium transition-colors cursor-pointer"
            >
              <span>{isSubmitting ? "Criando..." : "Criar estrutura do projeto"}</span>
              {!isSubmitting && <ArrowRight size={15} />}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
