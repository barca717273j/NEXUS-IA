import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Sale } from "../types";
import { TrendingUp } from "lucide-react";

interface SalesChartProps {
  sales: Sale[];
}

// Formata uma data no formato "YYYY-MM-DD" sem deixar o fuso horário do
// navegador deslocar o dia (o bug original usava `new Date(string)`, que o
// JS interpreta como UTC meia-noite e pode exibir o dia anterior).
function formatDateLabel(isoDate: string): string {
  const [year, month, day] = isoDate.split("-").map(Number);
  if (!year || !month || !day) return isoDate;
  return `${String(day).padStart(2, "0")}/${String(month).padStart(2, "0")}`;
}

function sortableKey(isoDate: string): string {
  return isoDate; // já está em YYYY-MM-DD, ordenação lexicográfica funciona
}

export default function SalesChart({ sales }: SalesChartProps) {
  const getChartData = () => {
    if (sales.length === 0) return [];

    const dataMap = new Map<string, { valor: number; count: number; sortKey: string }>();

    for (const sale of sales) {
      const label = formatDateLabel(sale.date);
      const existing = dataMap.get(label);
      if (existing) {
        existing.valor += sale.value;
        existing.count += 1;
      } else {
        dataMap.set(label, { valor: sale.value, count: 1, sortKey: sortableKey(sale.date) });
      }
    }

    return Array.from(dataMap.entries())
      .map(([date, v]) => ({ date, ...v }))
      .sort((a, b) => (a.sortKey < b.sortKey ? -1 : a.sortKey > b.sortKey ? 1 : 0))
      .slice(-14);
  };

  const chartData = getChartData();
  const totalRevenue = sales.reduce((sum, s) => sum + s.value, 0);

  return (
    <div className="bg-surface-1 border border-border p-6 rounded-xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp size={15} className="text-brand" />
            <h3 className="text-sm font-medium text-text-primary">Evolução de faturamento</h3>
          </div>
          <p className="text-xs text-text-muted">
            Total acumulado: <span className="text-text-secondary font-medium">R$ {totalRevenue.toLocaleString("pt-BR")}</span>
          </p>
        </div>
      </div>

      {chartData.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center text-center border border-dashed border-border rounded-lg">
          <p className="text-sm text-text-secondary font-medium">Nenhuma venda registrada ainda</p>
          <p className="text-xs text-text-muted mt-1 max-w-xs">
            O gráfico aparece automaticamente assim que você registrar a primeira venda.
          </p>
        </div>
      ) : (
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorValor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#B0212F" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#B0212F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1A1A1C" vertical={false} />
              <XAxis dataKey="date" stroke="#6B6967" fontSize={10} fontFamily="IBM Plex Mono, monospace" tickLine={false} axisLine={false} dy={10} />
              <YAxis stroke="#6B6967" fontSize={10} fontFamily="IBM Plex Mono, monospace" tickLine={false} axisLine={false} tickFormatter={(val) => `R$${val}`} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload as { date: string; valor: number; count: number };
                    return (
                      <div className="bg-surface-2 border border-border p-3 rounded-lg shadow-xl">
                        <p className="text-[10px] font-mono text-text-muted mb-1">{data.date}</p>
                        <p className="text-xs font-semibold text-brand">R$ {data.valor.toLocaleString("pt-BR")}</p>
                        <p className="text-[10px] text-text-secondary mt-0.5">
                          {data.count} {data.count === 1 ? "venda" : "vendas"}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area
                type="monotone"
                dataKey="valor"
                stroke="#B0212F"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorValor)"
                activeDot={{ r: 4, stroke: "#0B0B0C", strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
