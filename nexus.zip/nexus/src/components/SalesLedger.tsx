import { useState, useEffect, FormEvent } from "react";
import { motion } from "framer-motion";
import { Coins, Plus } from "lucide-react";
import { Project } from "../types";

interface SalesLedgerProps {
  projects: Project[];
  onRegisterSale: (projectId: string, sale: { value: number; date: string; note?: string }) => Promise<void>;
}

export default function SalesLedger({ projects, onRegisterSale }: SalesLedgerProps) {
  const [projectId, setProjectId] = useState(projects[0]?.id || "");
  const [value, setValue] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [note, setNote] = useState("");
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Mantém uma seleção válida mesmo se a lista de projetos mudar
  // (ex.: o projeto selecionado foi excluído, ou o primeiro projeto só
  // ficou disponível depois que este componente já havia montado).
  useEffect(() => {
    const stillExists = projects.some((p) => p.id === projectId);
    if (!stillExists) {
      setProjectId(projects[0]?.id || "");
    }
  }, [projects, projectId]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(value);
    if (isNaN(parsed) || parsed <= 0 || !projectId) return;

    setSubmitting(true);
    try {
      await onRegisterSale(projectId, { value: parsed, date, note: note.trim() || undefined });
      setValue("");
      setNote("");
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2500);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="max-w-2xl mx-auto"
    >
      <div className="p-6 bg-surface-1 border border-border rounded-xl">
        <div className="mb-6">
          <h3 className="text-sm font-medium text-text-primary flex items-center gap-2">
            <Coins size={15} className="text-brand" />
            Registro rápido de venda
          </h3>
          <p className="text-sm text-text-secondary mt-1.5">
            Registre vendas de qualquer um dos seus projetos a partir de um único lugar.
          </p>
        </div>

        {success && (
          <div className="mb-4 p-3 bg-success-soft border border-success/30 rounded-lg text-success text-sm text-center">
            Venda registrada com sucesso.
          </div>
        )}

        {projects.length === 0 ? (
          <p className="text-sm text-text-muted text-center py-6">
            Crie ao menos um projeto antes de registrar vendas.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-text-secondary">Projeto</label>
              <select
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary outline-none transition-colors cursor-pointer"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.ebook.title} ({p.niche})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-text-secondary">Valor (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder="Ex.: 97.00"
                  className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-text-secondary">Data</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary outline-none transition-colors"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-text-secondary">Observação (opcional)</label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Ex.: Venda via lista de e-mail"
                className="w-full px-4 py-2.5 bg-surface-2 border border-border focus:border-brand rounded-lg text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center gap-2 py-3 bg-brand hover:bg-brand-hover disabled:opacity-60 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
            >
              <Plus size={14} />
              <span>{submitting ? "Registrando..." : "Registrar venda"}</span>
            </button>
          </form>
        )}
      </div>
    </motion.div>
  );
}
