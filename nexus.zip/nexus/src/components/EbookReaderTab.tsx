import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, FileText } from "lucide-react";
import { Project } from "../types";
import { exportProjectToPdf } from "../data/pdfExport";

interface EbookReaderTabProps {
  project: Project;
}

export default function EbookReaderTab({ project }: EbookReaderTabProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const totalSections = project.ebook.chapters.length + 2; // introdução + capítulos + conclusão

  const sections = [
    { label: "Introdução", hint: "Abertura do material" },
    ...project.ebook.chapters.map((c) => ({ label: c.title, hint: "Capítulo" })),
    { label: "Conclusão", hint: "Fechamento e próximo passo" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="grid grid-cols-1 lg:grid-cols-12 gap-6"
    >
      {/* Navegador de seções */}
      <div className="lg:col-span-4 space-y-1.5">
        <div className="flex items-center justify-between mb-2 px-1">
          <p className="text-xs font-medium text-text-secondary">Estrutura do material</p>
          <button
            onClick={() => exportProjectToPdf(project)}
            className="flex items-center gap-1.5 text-xs text-text-muted hover:text-text-primary transition-colors cursor-pointer"
            title="Baixar como PDF"
          >
            <Download size={12} />
            <span>PDF</span>
          </button>
        </div>

        {sections.map((section, idx) => (
          <button
            key={idx}
            onClick={() => setActiveIndex(idx)}
            className={`w-full text-left p-3 rounded-lg border transition-colors cursor-pointer ${
              activeIndex === idx ? "border-brand bg-brand-soft" : "border-border bg-surface-1 hover:border-border-strong"
            }`}
          >
            <p className="text-sm font-medium text-text-primary truncate">{section.label}</p>
            <p className="text-xs text-text-muted mt-0.5">{section.hint}</p>
          </button>
        ))}
      </div>

      {/* Área de leitura */}
      <div className="lg:col-span-8 bg-surface-1 border border-border rounded-xl p-7 flex flex-col min-h-[420px]">
        <div className="flex justify-between items-center text-xs text-text-muted font-mono mb-6 pb-4 border-b border-border">
          <span className="flex items-center gap-1.5">
            <FileText size={12} />
            {project.language}
          </span>
          <span>{project.pages} páginas estimadas</span>
        </div>

        <div className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              {activeIndex === 0 ? (
                <div className="space-y-5">
                  <h3 className="font-serif text-xl font-semibold text-text-primary">{project.ebook.title}</h3>
                  <p className="text-sm text-text-secondary italic">{project.ebook.subtitle}</p>
                  <div className="pt-4 border-t border-border space-y-4">
                    <p className="text-sm text-text-secondary leading-relaxed">{project.ebook.summary}</p>
                    <p className="text-sm text-text-secondary leading-relaxed">{project.ebook.introduction}</p>
                  </div>
                </div>
              ) : activeIndex === totalSections - 1 ? (
                <div className="space-y-5">
                  <h3 className="font-serif text-xl font-semibold text-text-primary">Conclusão</h3>
                  <p className="text-sm text-text-secondary leading-relaxed">{project.ebook.conclusion}</p>
                  <div className="p-4 bg-brand-soft border border-brand-border rounded-xl">
                    <p className="text-xs font-medium text-brand uppercase tracking-wide mb-1.5">Próximo passo</p>
                    <p className="text-sm text-text-secondary leading-relaxed">{project.ebook.cta}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="font-serif text-xl font-semibold text-text-primary">
                    {project.ebook.chapters[activeIndex - 1].title}
                  </h3>
                  <p className="text-sm text-text-secondary leading-relaxed">
                    {project.ebook.chapters[activeIndex - 1].content}
                  </p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="border-t border-border pt-4 mt-6 flex justify-between items-center text-xs text-text-muted font-mono">
          <span>{activeIndex + 1} / {totalSections}</span>
          <div className="flex gap-2">
            <button
              disabled={activeIndex === 0}
              onClick={() => setActiveIndex((p) => p - 1)}
              className="px-3 py-1.5 bg-surface-2 border border-border hover:border-border-strong text-text-secondary disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer rounded-lg text-xs font-medium transition-colors"
            >
              Anterior
            </button>
            <button
              disabled={activeIndex === totalSections - 1}
              onClick={() => setActiveIndex((p) => p + 1)}
              className="px-3 py-1.5 bg-surface-2 border border-border hover:border-border-strong text-text-secondary disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer rounded-lg text-xs font-medium transition-colors"
            >
              Próximo
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
