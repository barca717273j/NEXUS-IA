import { motion } from "framer-motion";
import { Project } from "../types";
import { Info } from "lucide-react";

interface ResearchTabProps {
  project: Project;
}

export default function ResearchTab({ project }: ResearchTabProps) {
  const { research } = project;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="space-y-5"
    >
      <div className="flex items-start gap-2.5 p-3.5 bg-surface-1 border border-border rounded-xl">
        <Info size={14} className="text-text-muted mt-0.5 shrink-0" />
        <p className="text-xs text-text-secondary leading-relaxed">
          Este é um rascunho de pesquisa de público. Os campos abaixo precisam ser validados com
          dados reais — conversas, formulários ou comentários do seu público — antes de orientar
          decisões de conteúdo ou preço.
        </p>
      </div>

      <div className="bg-surface-1 border border-border p-6 rounded-xl grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <p className="text-xs text-text-muted mb-1">Persona</p>
          <h3 className="font-serif text-lg font-semibold text-text-primary">{research.avatar.name}</h3>
          <p className="text-sm text-text-secondary mt-1.5 leading-relaxed">{research.avatar.idealAudience}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-text-muted">Faixa etária</p>
            <p className="text-sm text-text-primary mt-0.5">{research.avatar.age}</p>
          </div>
          <div>
            <p className="text-xs text-text-muted">Profissão</p>
            <p className="text-sm text-text-primary mt-0.5">{research.avatar.profession}</p>
          </div>
          <div>
            <p className="text-xs text-text-muted">Renda estimada</p>
            <p className="text-sm text-text-primary mt-0.5">{research.avatar.income}</p>
          </div>
          <div>
            <p className="text-xs text-text-muted">Localização</p>
            <p className="text-sm text-text-primary mt-0.5">{research.avatar.city}</p>
          </div>
        </div>

        <div>
          <p className="text-xs text-text-muted mb-2">Interesses a validar</p>
          <div className="flex flex-wrap gap-1.5">
            {research.avatar.interests.map((interest, idx) => (
              <span key={idx} className="px-2.5 py-1 bg-surface-2 border border-border rounded-md text-xs text-text-secondary">
                {interest}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Dores a confirmar</h4>
          <ul className="space-y-2.5">
            {research.avatar.pains.map((pain, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-brand mt-2 shrink-0" />
                <span>{pain}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Objetivos a confirmar</h4>
          <ul className="space-y-2.5">
            {research.avatar.dreams.map((dream, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-brand mt-2 shrink-0" />
                <span>{dream}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Objeções comuns</h4>
          <ul className="space-y-2.5">
            {research.objections.map((obj, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-brand mt-2 shrink-0" />
                <span>{obj}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Tom de voz</h4>
          <p className="text-sm text-text-secondary leading-relaxed mb-3">{research.toneOfVoice}</p>
          <div className="flex flex-wrap gap-1.5">
            {research.convertingWords.map((word, idx) => (
              <span key={idx} className="px-2.5 py-1 bg-surface-2 border border-border rounded-md text-xs text-text-secondary">
                {word}
              </span>
            ))}
          </div>
        </div>

        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Promessas a sustentar</h4>
          <ul className="space-y-2.5">
            {research.promises.map((prom, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-brand mt-2 shrink-0" />
                <span>{prom}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 bg-surface-1 border border-border rounded-xl">
          <h4 className="text-xs font-medium text-brand uppercase tracking-wide mb-3">Benefícios e argumentos</h4>
          <ul className="space-y-1.5 mb-3">
            {research.benefits.map((ben, idx) => (
              <li key={idx} className="text-xs text-text-secondary leading-relaxed flex items-start gap-1.5">
                <span className="w-1 h-1 rounded-full bg-text-muted mt-1.5 shrink-0" />
                <span>{ben}</span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-text-secondary italic leading-relaxed">{research.arguments[0]}</p>
        </div>
      </div>
    </motion.div>
  );
}
