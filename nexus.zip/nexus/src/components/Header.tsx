import { useState, useRef, useEffect } from "react";
import { Settings, User, LogOut, Monitor, Smartphone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface HeaderProps {
  userName: string;
  userEmail: string;
  onOpenSettings: () => void;
  onLogout: () => void;
  viewMode: "desktop" | "mobile";
  setViewMode: (mode: "desktop" | "mobile") => void;
}

export default function Header({
  userName,
  userEmail,
  onOpenSettings,
  onLogout,
  viewMode,
  setViewMode,
}: HeaderProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowProfileMenu(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between w-full h-16 px-6 sm:px-8 bg-surface-0/95 backdrop-blur-sm border-b border-border">
      <div className="flex items-center gap-5">
        <span className="text-xs font-mono text-text-muted hidden md:block">
          Espaço de trabalho
        </span>

        {/* Alternador de pré-visualização desktop/celular */}
        <div className="flex bg-surface-1 border border-border p-0.5 rounded-md">
          <button
            onClick={() => setViewMode("desktop")}
            className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === "desktop" ? "bg-surface-2 text-text-primary" : "text-text-muted hover:text-text-secondary"
            }`}
            title="Pré-visualizar em tela cheia"
          >
            <Monitor size={13} />
            <span className="hidden sm:inline">Tela cheia</span>
          </button>
          <button
            onClick={() => setViewMode("mobile")}
            className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === "mobile" ? "bg-surface-2 text-text-primary" : "text-text-muted hover:text-text-secondary"
            }`}
            title="Pré-visualizar como em um celular"
          >
            <Smartphone size={13} />
            <span className="hidden sm:inline">Celular</span>
          </button>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-lg hover:bg-surface-1 text-text-muted hover:text-text-primary transition-colors cursor-pointer"
          title="Configurações"
        >
          <Settings size={17} />
        </button>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setShowProfileMenu((v) => !v)}
            className="flex items-center gap-2.5 p-1 pl-2.5 rounded-full hover:bg-surface-1 border border-transparent hover:border-border transition-colors cursor-pointer"
          >
            <span className="text-sm text-text-secondary hidden sm:inline-block">{userName}</span>
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-surface-1 border border-border text-text-secondary font-medium text-xs">
              {userName.substring(0, 2).toUpperCase()}
            </div>
          </button>

          <AnimatePresence>
            {showProfileMenu && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-56 rounded-xl bg-surface-1 border border-border shadow-xl z-50 p-1.5"
              >
                <div className="px-3 py-2.5 border-b border-border mb-1">
                  <p className="text-sm font-medium text-text-primary truncate">{userName}</p>
                  <p className="text-xs text-text-muted truncate mt-0.5">{userEmail}</p>
                </div>

                <button
                  onClick={() => { setShowProfileMenu(false); onOpenSettings(); }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-text-secondary hover:text-text-primary hover:bg-surface-2 transition-colors text-left cursor-pointer"
                >
                  <User size={14} />
                  <span>Configurações</span>
                </button>
                <button
                  onClick={() => { setShowProfileMenu(false); onLogout(); }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm text-text-secondary hover:text-text-primary hover:bg-surface-2 transition-colors text-left cursor-pointer"
                >
                  <LogOut size={14} />
                  <span>Sair</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
