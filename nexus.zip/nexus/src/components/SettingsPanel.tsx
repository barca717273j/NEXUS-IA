import { useState } from "react";
import { motion } from "framer-motion";
import { RotateCcw } from "lucide-react";
import { UserProfile } from "../types";

interface SettingsPanelProps {
  profile: UserProfile;
  onUpdateGoal: (goal: number) => Promise<void>;
  onDeleteAllProjects: () => Promise<void>;
}

export default function SettingsPanel({ profile, onUpdateGoal, onDeleteAllProjects }: SettingsPanelProps) {
  const [goal, setGoal] = useState(profile.monthlyGoal);
  const [savingGoal, setSavingGoal] = useState(false);
  const [confirmingReset, setConfirmingReset] = useState(false);

  const handleGoalChange = async (value: number) => {
    setGoal(value);
    setSavingGoal(true);
    try {
      await onUpdateGoal(value);
    } finally {
      setSavingGoal(false);
    }
  };

  const handleResetClick = async () => {
    if (!confirmingReset) {
      setConfirmingReset(true);
      setTimeout(() => setConfirmingReset(false), 4000);
      return;
    }
    await onDeleteAllProjects();
    setConfirmingReset(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="max-w-2xl mx-auto space-y-5"
    >
      <div className="bg-surface-1 border border-border p-6 rounded-xl">
        <h3 className="text-sm font-medium text-text-primary mb-4">Meta mensal de vendas</h3>
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-text-secondary flex justify-between">
            <span>Defina sua meta</span>
            <span className="text-brand font-mono">
              R$ {goal.toLocaleString("pt-BR")} {savingGoal && "· salvando..."}
            </span>
          </label>
          <input
            type="range"
            min={500}
            max={50000}
            step={500}
            value={goal}
            onChange={(e) => handleGoalChange(Number(e.target.value))}
            className="w-full accent-brand cursor-pointer"
          />
        </div>
        <p className="text-xs text-text-muted mt-3">
          A meta é usada para calcular o progresso mostrado no painel principal.
        </p>
      </div>

      <div className="bg-surface-1 border border-border p-6 rounded-xl">
        <h3 className="text-sm font-medium text-text-primary mb-4">Conta</h3>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between py-2 border-b border-border">
            <span className="text-text-muted">Nome</span>
            <span className="text-text-primary">{profile.fullName || "—"}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-text-muted">E-mail</span>
            <span className="text-text-primary">{profile.email}</span>
          </div>
        </div>
      </div>

      <div className="bg-brand-soft border border-brand-border p-6 rounded-xl">
        <h3 className="text-sm font-medium text-text-primary mb-2">Zona de risco</h3>
        <p className="text-xs text-text-secondary mb-4 leading-relaxed">
          Remove permanentemente todos os seus projetos e vendas registradas. Esta ação não pode ser desfeita.
        </p>
        <button
          onClick={handleResetClick}
          className="flex items-center gap-2 px-4 py-2.5 bg-surface-1 border border-brand-border hover:bg-brand hover:text-white text-brand rounded-lg text-sm font-medium transition-colors cursor-pointer"
        >
          <RotateCcw size={14} />
          <span>{confirmingReset ? "Clique novamente para confirmar" : "Excluir todos os projetos"}</span>
        </button>
      </div>
    </motion.div>
  );
}
