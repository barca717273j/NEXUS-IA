import { Terminal, Database } from "lucide-react";

export default function SetupNotice() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-0 px-6 py-12">
      <div className="w-full max-w-lg border border-border bg-surface-1 rounded-2xl p-8 sm:p-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-brand-soft border border-brand-border text-brand shrink-0">
            <Database size={18} />
          </div>
          <h1 className="font-serif text-xl font-semibold text-text-primary">
            Conecte o Supabase para continuar
          </h1>
        </div>

        <p className="text-sm text-text-secondary leading-relaxed mb-6">
          O NEXUS usa o Supabase para autenticação e armazenamento de dados.
          As credenciais ainda não foram configuradas neste ambiente.
        </p>

        <ol className="space-y-4 text-sm text-text-secondary mb-6">
          <li className="flex gap-3">
            <span className="font-mono text-brand font-semibold shrink-0">1.</span>
            <span>
              Crie um projeto em{" "}
              <span className="text-text-primary font-medium">supabase.com</span> e copie a{" "}
              <span className="text-text-primary font-medium">Project URL</span> e a{" "}
              <span className="text-text-primary font-medium">anon key</span> em
              Project Settings → API.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="font-mono text-brand font-semibold shrink-0">2.</span>
            <span>
              Rode o arquivo <code className="text-text-primary font-mono text-xs bg-surface-2 px-1.5 py-0.5 rounded">supabase_schema.sql</code> no
              SQL Editor do seu projeto Supabase.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="font-mono text-brand font-semibold shrink-0">3.</span>
            <span>
              Copie <code className="text-text-primary font-mono text-xs bg-surface-2 px-1.5 py-0.5 rounded">.env.example</code> para{" "}
              <code className="text-text-primary font-mono text-xs bg-surface-2 px-1.5 py-0.5 rounded">.env.local</code> e preencha os dois valores.
            </span>
          </li>
        </ol>

        <div className="flex items-start gap-3 p-4 rounded-xl bg-surface-2 border border-border">
          <Terminal size={15} className="text-text-muted mt-0.5 shrink-0" />
          <code className="text-xs font-mono text-text-secondary leading-relaxed">
            VITE_SUPABASE_URL="https://seu-projeto.supabase.co"<br />
            VITE_SUPABASE_ANON_KEY="sua-chave-anon"
          </code>
        </div>

        <p className="text-xs text-text-muted mt-6">
          Depois de salvar o arquivo, reinicie o servidor de desenvolvimento.
        </p>
      </div>
    </div>
  );
}
