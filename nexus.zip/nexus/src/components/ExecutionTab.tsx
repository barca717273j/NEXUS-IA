import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { Project, ProjectMilestones } from "../types";

interface ExecutionTabProps {
  project: Project;
  onToggleMilestone: (key: keyof ProjectMilestones) => void;
}

const ITEMS: Array<{ key: keyof ProjectMilestones; title: string; description: string }> = [
  {
    key: "ebookCreated",
    title: "Estrutura do material criada",
    description: "Capítulos, introdução, conclusão e chamada para ação organizados.",
  },
  {
    key: "researchCompleted",
    title: "Pesquisa de público validada",
    description: "Persona, dores e objeções confirmadas com dados reais — não apenas suposições.",
  },
  {
    key: "messagesReady",
    title: "Conteúdo de divulgação revisado",
    description: "Modelos de mensagem personalizados com sua própria voz, prontos para uso.",
  },
  {
    key: "communitiesAnalyzed",
    title: "Canais de divulgação mapeados",
    description: "Comunidades e canais reais identificados, com regras de postagem conferidas.",
  },
  {
    key: "firstPromoDone",
    title: "Primeira divulgação publicada",
    description: "Você compartilhou conteúdo ou contatou alguém sobre o produto.",
  },
  {
    key: "firstSaleRegistered",
    title: "Primeira venda registrada",
    description: "Marcado automaticamente quando você registra uma venda na aba Vendas.",
  },
];

export default function ExecutionTab({ project, onToggleMilestone }: ExecutionTabProps) {
  const completedCount = ITEMS.filter((item) => project.milestones[item.key]).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="max-w-2xl mx-auto space-y-5"
    >
      <div className="bg-surface-1 border border-border p-6 rounded-xl">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-text-primary">Plano de execução</h3>
            <p className="text-xs text-text-muted mt-1">Marque cada etapa conforme avança.</p>
          </div>
          <span className="text-xs font-mono text-text-muted">{completedCount}/{ITEMS.length}</span>
        </div>

        <div className="divide-y divide-border">
          {ITEMS.map((item) => {
            const done = project.milestones[item.key];
            const isAutomatic = item.key === "firstSaleRegistered";
            return (
              <div
                key={item.key}
                onClick={() => !isAutomatic && onToggleMilestone(item.key)}
                className={`py-4 flex items-start gap-3.5 ${isAutomatic ? "" : "cursor-pointer"}`}
              >
                <div
                  className={`w-4.5 h-4.5 mt-0.5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                    done ? "bg-brand border-brand text-white" : "border-border-strong bg-surface-2"
                  }`}
                >
                  {done && <Check size={11} strokeWidth={3} />}
                </div>
                <div>
                  <p className={`text-sm font-medium ${done ? "text-text-muted line-through" : "text-text-primary"}`}>
                    {item.title}
                  </p>
                  <p className="text-xs text-text-muted mt-0.5">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}
