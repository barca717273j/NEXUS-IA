import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { Mail, Lock, User, ArrowRight, AlertCircle } from "lucide-react";
import { useAuth } from "../hooks/useAuth";

export default function Auth() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setInfo("");

    if (!email.trim() || !password) {
      setError("Preencha e-mail e senha.");
      return;
    }
    if (mode === "signup" && !name.trim()) {
      setError("Informe seu nome.");
      return;
    }
    if (password.length < 6) {
      setError("A senha precisa ter pelo menos 6 caracteres.");
      return;
    }

    setSubmitting(true);
    try {
      if (mode === "signin") {
        await signIn(email.trim(), password);
      } else {
        await signUp(name.trim(), email.trim(), password);
        setInfo("Conta criada. Verifique seu e-mail para confirmar o acesso, se a confirmação estiver ativada no seu projeto Supabase.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível concluir. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-0 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
        className="w-full max-w-md border border-border bg-surface-1 rounded-2xl p-8 sm:p-10"
      >
        <div className="mb-8">
          <div className="flex items-center gap-2.5 mb-1">
            <span className="w-2 h-2 rounded-full bg-brand" />
            <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-text-muted">
              Nexus
            </span>
          </div>
          <h1 className="font-serif text-2xl font-semibold text-text-primary">
            {mode === "signin" ? "Acesse sua conta" : "Crie sua conta"}
          </h1>
          <p className="text-sm text-text-secondary mt-1.5">
            {mode === "signin"
              ? "Entre para continuar seus projetos."
              : "Comece a estruturar seu primeiro produto digital."}
          </p>
        </div>

        <div className="flex border-b border-border mb-6">
          <button
            type="button"
            onClick={() => { setMode("signin"); setError(""); setInfo(""); }}
            className={`flex-1 pb-3 text-sm font-medium transition-colors cursor-pointer ${
              mode === "signin"
                ? "text-text-primary border-b-2 border-brand"
                : "text-text-muted hover:text-text-secondary"
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => { setMode("signup"); setError(""); setInfo(""); }}
            className={`flex-1 pb-3 text-sm font-medium transition-colors cursor-pointer ${
              mode === "signup"
                ? "text-text-primary border-b-2 border-brand"
                : "text-text-muted hover:text-text-secondary"
            }`}
          >
            Cadastrar
          </button>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 p-3 bg-brand-soft border border-brand-border rounded-xl text-sm text-text-primary">
            <AlertCircle size={15} className="text-brand mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {info && (
          <div className="mb-4 p-3 bg-success-soft border border-success/30 rounded-xl text-sm text-text-primary">
            {info}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "signup" && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-text-secondary">Nome</label>
              <div className="relative">
                <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome"
                  className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-text-secondary">E-mail</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                autoComplete="email"
                className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-text-secondary">Senha</label>
            <div className="relative">
              <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo de 6 caracteres"
                autoComplete={mode === "signin" ? "current-password" : "new-password"}
                className="w-full pl-10 pr-4 py-3 bg-surface-2 border border-border focus:border-brand rounded-xl text-sm text-text-primary placeholder-text-muted outline-none transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 py-3 mt-2 rounded-xl bg-brand hover:bg-brand-hover disabled:opacity-60 text-white text-sm font-medium transition-colors cursor-pointer"
          >
            <span>{submitting ? "Processando..." : mode === "signin" ? "Entrar" : "Criar conta"}</span>
            {!submitting && <ArrowRight size={15} />}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
