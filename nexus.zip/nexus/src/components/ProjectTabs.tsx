import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { BookOpen, Search, Megaphone, CheckSquare, DollarSign } from "lucide-react";
import { Project, ProjectMilestones } from "../types";
import EbookReaderTab from "./EbookReaderTab";
import ResearchTab from "./ResearchTab";
import OutreachTab from "./OutreachTab";
import ExecutionTab from "./ExecutionTab";
import SalesTab from "./SalesTab";

interface ProjectTabsProps {
  project: Project;
  onToggleMilestone: (key: keyof ProjectMilestones) => void;
  onRegisterSale: (sale: { value: number; date: string; note?: string }) => Promise<void>;
  onDeleteSale: (saleId: string) => Promise<void>;
}

const TABS = [
  { id: "ebook", label: "Material", icon: BookOpen },
  { id: "research", label: "Pesquisa", icon: Search },
  { id: "outreach", label: "Divulgação", icon: Megaphone },
  { id: "execution", label: "Execução", icon: CheckSquare },
  { id: "sales", label: "Vendas", icon: DollarSign },
] as const;

type TabId = (typeof TABS)[number]["id"];

export default function ProjectTabs({ project, onToggleMilestone, onRegisterSale, onDeleteSale }: ProjectTabsProps) {
  const [activeTab, setActiveTab] = useState<TabId>("ebook");

  return (
    <div className="w-full">
      {/* Resumo do projeto */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 p-6 bg-surface-1 border border-border border-b-0 rounded-t-xl">
        <div>
          <div className="flex items-center gap-3 mb-1.5">
            <span className="px-2.5 py-0.5 bg-brand-soft border border-brand-border text-xs text-brand font-medium rounded-md">
              {project.niche}
            </span>
            <span className="text-xs text-text-muted font-mono">
              Criado em {new Date(project.createdAt).toLocaleDateString("pt-BR")}
            </span>
          </div>
          <h1 className="font-serif text-2xl font-semibold text-text-primary">{project.ebook.title}</h1>
          <p className="text-sm text-text-secondary mt-1.5 max-w-2xl leading-relaxed">{project.objective}</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-12 h-16 bg-surface-2 border border-border rounded-lg overflow-hidden shrink-0">
            <img src={project.coverUrl} alt="Capa" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <div className="hidden sm:block text-right">
            <p className="text-xs text-text-muted">{project.pages} páginas estimadas</p>
            <p className="text-xs text-text-muted mt-0.5">{project.language}</p>
          </div>
        </div>
      </div>

      {/* Navegação por abas */}
      <div className="flex flex-wrap border-b border-border bg-surface-0 px-2">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3.5 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                isActive ? "text-text-primary border-brand" : "text-text-muted border-transparent hover:text-text-secondary"
              }`}
            >
              <Icon size={14} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="bg-surface-0 border border-border border-t-0 p-6 md:p-7 rounded-b-xl min-h-[450px]">
        <AnimatePresence mode="wait">
          {activeTab === "ebook" && <EbookReaderTab key="ebook" project={project} />}
          {activeTab === "research" && <ResearchTab key="research" project={project} />}
          {activeTab === "outreach" && <OutreachTab key="outreach" project={project} />}
          {activeTab === "execution" && (
            <ExecutionTab key="execution" project={project} onToggleMilestone={onToggleMilestone} />
          )}
          {activeTab === "sales" && (
            <SalesTab key="sales" project={project} onRegisterSale={onRegisterSale} onDeleteSale={onDeleteSale} />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
