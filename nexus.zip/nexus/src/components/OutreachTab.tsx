import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, Megaphone, Users, MessageCircle, Mail } from "lucide-react";
import { Project, OutreachPlan } from "../types";

interface OutreachTabProps {
  project: Project;
}

const CATEGORY_ICONS: Record<keyof OutreachPlan, typeof Megaphone> = {
  socialPosts: Megaphone,
  communities: Users,
  directOutreach: MessageCircle,
  emailList: Mail,
};

export default function OutreachTab({ project }: OutreachTabProps) {
  const categories = Object.keys(project.outreach) as Array<keyof OutreachPlan>;
  const [active, setActive] = useState<keyof OutreachPlan>(categories[0]);
  const [copied, setCopied] = useState(false);

  const activeChannel = project.outreach[active];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeChannel.messageTemplate);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="grid grid-cols-1 lg:grid-cols-12 gap-6"
    >
      <div className="lg:col-span-4 space-y-1.5">
        <p className="text-xs font-medium text-text-secondary mb-2 px-1">Canais de divulgação</p>
        {categories.map((key) => {
          const Icon = CATEGORY_ICONS[key];
          const channel = project.outreach[key];
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => setActive(key)}
              className={`w-full text-left p-3.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-3 ${
                isActive ? "border-brand bg-brand-soft" : "border-border bg-surface-1 hover:border-border-strong"
              }`}
            >
              <Icon size={16} className={isActive ? "text-brand" : "text-text-muted"} />
              <span className="text-sm font-medium text-text-primary">{channel.category}</span>
            </button>
          );
        })}
      </div>

      <div className="lg:col-span-8 bg-surface-1 border border-border rounded-xl p-6 space-y-6">
        <div>
          <h3 className="text-sm font-medium text-text-primary mb-3">Boas práticas para {activeChannel.category.toLowerCase()}</h3>
          <ul className="space-y-2">
            {activeChannel.channelTips.map((tip, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-brand mt-2 shrink-0" />
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="pt-5 border-t border-border">
          <h3 className="text-sm font-medium text-text-primary mb-3">Ideias de conteúdo</h3>
          <ul className="space-y-2">
            {activeChannel.contentIdeas.map((idea, idx) => (
              <li key={idx} className="text-sm text-text-secondary leading-relaxed flex items-start gap-2">
                <span className="w-1 h-1 rounded-full bg-text-muted mt-2 shrink-0" />
                <span>{idea}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="pt-5 border-t border-border">
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="text-sm font-medium text-text-primary">Modelo de mensagem</h3>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-surface-2 border border-border hover:border-border-strong text-text-secondary rounded-md text-xs font-medium transition-colors cursor-pointer"
            >
              {copied ? <Check size={12} className="text-success" /> : <Copy size={12} />}
              <span>{copied ? "Copiado" : "Copiar"}</span>
            </button>
          </div>
          <div className="p-4 bg-surface-2 border border-border rounded-lg text-sm text-text-secondary leading-relaxed whitespace-pre-wrap">
            {activeChannel.messageTemplate}
          </div>
          <p className="text-xs text-text-muted mt-2.5">
            Edite o modelo com sua voz antes de publicar — mensagens copiadas sem personalização tendem a parecer spam e violam as regras da maioria das comunidades.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
