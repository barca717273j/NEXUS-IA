import { FolderKanban, Layers, DollarSign, Target } from "lucide-react";
import { motion } from "framer-motion";

interface MetricCardsProps {
  totalProjects: number;
  projectsWithoutSales: number;
  totalSalesCount: number;
  totalRevenue: number;
  monthlyGoal: number;
}

export default function MetricCards({
  totalProjects,
  projectsWithoutSales,
  totalSalesCount,
  totalRevenue,
  monthlyGoal,
}: MetricCardsProps) {
  const goalProgress = monthlyGoal > 0 ? Math.min(100, Math.round((totalRevenue / monthlyGoal) * 100)) : 0;

  const stats = [
    {
      id: "stat-projects",
      label: "Total de projetos",
      value: totalProjects,
      subtext: "Produtos digitais estruturados",
      icon: Layers,
    },
    {
      id: "stat-pending",
      label: "Sem vendas registradas",
      value: projectsWithoutSales,
      subtext: "Projetos aguardando o primeiro registro",
      icon: FolderKanban,
    },
    {
      id: "stat-sales",
      label: "Faturamento total",
      value: `R$ ${totalRevenue.toLocaleString("pt-BR")}`,
      subtext: `${totalSalesCount} ${totalSalesCount === 1 ? "venda registrada" : "vendas registradas"}`,
      icon: DollarSign,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: idx * 0.05 }}
            className="p-5 bg-surface-1 border border-border rounded-xl"
          >
            <div className="flex justify-between items-start mb-4">
              <p className="text-xs text-text-secondary font-medium">{stat.label}</p>
              <Icon size={15} className="text-text-muted" />
            </div>
            <h3 className="text-2xl font-serif font-semibold text-text-primary mb-1.5">
              {stat.value}
            </h3>
            <p className="text-xs text-text-muted">{stat.subtext}</p>
          </motion.div>
        );
      })}

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, delay: 0.15 }}
        className="p-5 bg-surface-1 border border-border rounded-xl flex flex-col justify-between"
      >
        <div className="flex justify-between items-start mb-3">
          <p className="text-xs text-text-secondary font-medium">Meta mensal</p>
          <Target size={15} className="text-text-muted" />
        </div>
        <div className="flex items-baseline gap-1.5 mb-3">
          <h3 className="text-2xl font-serif font-semibold text-brand">{goalProgress}%</h3>
          <span className="text-xs text-text-muted">de R$ {monthlyGoal.toLocaleString("pt-BR")}</span>
        </div>
        <div className="w-full bg-surface-2 rounded-full h-1.5 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${goalProgress}%` }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="bg-brand h-full rounded-full"
          />
        </div>
      </motion.div>
    </div>
  );
}
