import { motion } from "framer-motion";
import {
  LayoutDashboard,
  FolderPlus,
  Library,
  CircleDollarSign,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  hasActiveProject: boolean;
  userName: string;
  isMobileView?: boolean;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  onLogout,
  collapsed,
  setCollapsed,
  hasActiveProject,
  userName,
  isMobileView = false,
}: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Painel", icon: LayoutDashboard },
    { id: "new-project", label: "Novo projeto", icon: FolderPlus },
    ...(hasActiveProject ? [{ id: "library", label: "Biblioteca", icon: Library }] : []),
    { id: "sales-ledger", label: "Vendas", icon: CircleDollarSign },
    { id: "settings", label: "Configurações", icon: Settings },
  ];

  const getInitials = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return "?";
    return trimmed
      .split(" ")
      .map((n) => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  };

  return (
    <motion.aside
      animate={
        isMobileView
          ? { x: collapsed ? "-100%" : "0%", width: "260px" }
          : { x: "0%", width: collapsed ? "76px" : "260px" }
      }
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className={`${
        isMobileView ? "absolute h-full z-50 shadow-2xl" : "fixed h-screen z-40"
      } inset-y-0 left-0 flex flex-col border-r border-border bg-surface-1`}
    >
      {/* Cabeçalho da marca */}
      <div className="flex items-center h-20 px-6 border-b border-border relative shrink-0">
        {(!collapsed || isMobileView) && (
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-7 h-7 rounded-md bg-brand shrink-0">
              <span className="text-white font-serif font-bold text-sm">N</span>
            </div>
            <span className="font-serif text-lg font-semibold text-text-primary tracking-tight">
              Nexus
            </span>
          </div>
        )}

        {collapsed && !isMobileView && (
          <div className="mx-auto flex items-center justify-center w-8 h-8 rounded-md bg-brand">
            <span className="text-white font-serif font-bold text-sm">N</span>
          </div>
        )}

        {isMobileView && (
          <button
            onClick={() => setCollapsed(true)}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1.5 rounded-lg border border-border text-text-muted hover:text-text-primary hover:border-border-strong transition-colors cursor-pointer"
            title="Fechar menu"
          >
            <ChevronLeft size={16} />
          </button>
        )}

        {!isMobileView && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="absolute right-[-13px] top-8 hidden md:flex items-center justify-center w-6 h-6 rounded-full bg-surface-2 border border-border hover:border-border-strong text-text-muted hover:text-text-primary transition-colors cursor-pointer"
          >
            {collapsed ? <ChevronRight size={13} /> : <ChevronLeft size={13} />}
          </button>
        )}
      </div>

      {/* Navegação */}
      <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors relative group cursor-pointer ${
                isActive
                  ? "text-text-primary bg-brand-soft"
                  : "text-text-secondary hover:text-text-primary hover:bg-surface-2"
              }`}
            >
              <Icon size={17} className={isActive ? "text-brand" : "text-text-muted group-hover:text-text-secondary"} />
              {!collapsed && <span className="truncate">{item.label}</span>}
              {collapsed && !isMobileView && (
                <div className="absolute left-16 scale-0 group-hover:scale-100 transition-transform origin-left bg-surface-2 text-text-primary text-xs px-2.5 py-1.5 rounded-md border border-border whitespace-nowrap z-50">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Rodapé: conta e logout */}
      <div className="border-t border-border p-3 shrink-0">
        {!collapsed ? (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3 px-1 py-1.5">
              <div className="w-8 h-8 rounded-full bg-surface-2 border border-border flex items-center justify-center font-serif font-semibold text-text-secondary text-xs shrink-0">
                {getInitials(userName)}
              </div>
              <span className="text-sm font-medium text-text-primary truncate">{userName}</span>
            </div>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm text-text-secondary hover:text-text-primary hover:bg-surface-2 transition-colors cursor-pointer"
            >
              <LogOut size={16} />
              <span>Sair</span>
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div
              className="w-8 h-8 rounded-full bg-surface-2 border border-border flex items-center justify-center font-serif font-semibold text-text-secondary text-xs"
              title={userName}
            >
              {getInitials(userName)}
            </div>
            <button
              onClick={onLogout}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-text-muted hover:text-text-primary hover:bg-surface-2 transition-colors cursor-pointer"
              title="Sair"
            >
              <LogOut size={15} />
            </button>
          </div>
        )}
      </div>
    </motion.aside>
  );
}
