import { useEffect, useState, useCallback } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";
import { UserProfile } from "../types";

interface ProfileRow {
  id: string;
  full_name: string;
  monthly_goal: number;
}

async function fetchProfile(user: User): Promise<UserProfile> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, full_name, monthly_goal")
    .eq("id", user.id)
    .maybeSingle();

  // O gatilho do banco cria o perfil automaticamente no cadastro. Se por algum
  // motivo ele ainda não existir (ex.: corrida entre o trigger e esta leitura),
  // tratamos com um perfil padrão em vez de travar a tela.
  if (error || !data) {
    return {
      id: user.id,
      fullName: (user.user_metadata?.full_name as string) || "",
      email: user.email || "",
      monthlyGoal: 5000,
    };
  }

  const row = data as ProfileRow;
  return {
    id: row.id,
    fullName: row.full_name,
    email: user.email || "",
    monthlyGoal: Number(row.monthly_goal),
  };
}

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    supabase.auth.getSession().then(async ({ data }) => {
      if (!isMounted) return;
      setSession(data.session);
      if (data.session?.user) {
        const p = await fetchProfile(data.session.user);
        if (isMounted) setProfile(p);
      }
      if (isMounted) setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      if (!isMounted) return;
      setSession(newSession);
      if (newSession?.user) {
        const p = await fetchProfile(newSession.user);
        if (isMounted) setProfile(p);
      } else {
        setProfile(null);
      }
    });

    return () => {
      isMounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const signUp = useCallback(async (fullName: string, email: string, password: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    if (error) throw error;
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const updateMonthlyGoal = useCallback(
    async (goal: number) => {
      if (!session?.user) return;
      const { error } = await supabase
        .from("profiles")
        .update({ monthly_goal: goal })
        .eq("id", session.user.id);
      if (error) throw error;
      setProfile((prev) => (prev ? { ...prev, monthlyGoal: goal } : prev));
    },
    [session]
  );

  return {
    session,
    user: session?.user ?? null,
    profile,
    loading,
    signUp,
    signIn,
    signOut,
    updateMonthlyGoal,
  };
}
