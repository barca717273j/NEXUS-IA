import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
    supabaseAnonKey &&
    !supabaseUrl.includes("SEU-PROJETO") &&
    !supabaseAnonKey.includes("SUA_CHAVE_ANON")
);

// Em desenvolvimento, se as credenciais ainda não foram preenchidas,
// criamos um cliente "apontando para lugar nenhum" para que o app não quebre
// ao importar este módulo. A tela de configuração cuida de avisar o usuário.
export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder-anon-key"
);
