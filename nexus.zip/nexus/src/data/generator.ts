import {
  Project,
  EbookContent,
  Research,
  Chapter,
  OutreachPlan,
} from "../types";

// ----------------------------------------------------------------------------
// Motor de geração de conteúdo do NEXUS
// ----------------------------------------------------------------------------
// Este módulo monta a estrutura inicial de um produto digital (ebook + plano
// de pesquisa de público + plano de divulgação) a partir do nicho e do
// objetivo informados pelo usuário. A geração é determinística — não há
// chamada a nenhum modelo de linguagem — e serve como um rascunho estrutural
// para o usuário editar, completar e personalizar com sua própria voz antes
// de publicar. Pense nisso como um framework de redação, não como um
// substituto para escrever o conteúdo final.
// ----------------------------------------------------------------------------

function titleCase(word: string): string {
  if (!word) return word;
  return word.charAt(0).toUpperCase() + word.slice(1);
}

function pickCoverUrl(niche: string, customUrl?: string): string {
  if (customUrl && customUrl.trim()) return customUrl.trim();

  const lower = niche.toLowerCase();
  const matchers: Array<[string[], string]> = [
    [
      ["emagrec", "saúde", "saude", "nutri", "fit", "dieta"],
      "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=800",
    ],
    [
      ["dinheiro", "finança", "financa", "venda", "invest", "negócio", "negocio"],
      "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&q=80&w=800",
    ],
    [
      ["marketing", "digital", "tráfego", "trafego", "copy"],
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
    ],
    [
      ["program", "código", "codigo", "tech", "software", "dados"],
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=800",
    ],
    [
      ["mental", "mindset", "produti", "foco", "tempo", "hábito", "habito"],
      "https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=800",
    ],
  ];

  for (const [keywords, url] of matchers) {
    if (keywords.some((k) => lower.includes(k))) return url;
  }
  return "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800";
}

function buildEbook(
  productName: string,
  niche: string,
  objective: string
): EbookContent {
  const cleanObjective = objective.replace(/^(ajudar a|ensinar a|ajudar|ensinar)\s*/i, "").trim();
  const keywords = cleanObjective
    .split(" ")
    .map((w) => w.replace(/[.,;:]/g, ""))
    .filter((w) => w.length > 4);
  const focusWord = titleCase(keywords[0] || niche.split(" ")[0] || "Resultado");

  const title = `${productName || `Guia de ${titleCase(niche)}`}`;
  const subtitle = `Um plano estruturado para ${cleanObjective.toLowerCase() || `evoluir em ${niche.toLowerCase()}`}, dividido em etapas claras e aplicáveis.`;

  const summary = `Este material reúne uma estrutura de conteúdo para ${niche}, organizada em capítulos progressivos. Use-o como ponto de partida: substitua os exemplos genéricos por casos reais, sua própria experiência e dados que sustentem cada afirmação antes de publicar.`;

  const introduction = `Este é um rascunho inicial gerado a partir do nicho e do objetivo que você descreveu. Ele traz uma arquitetura de capítulos coerente para ${niche.toLowerCase()}, mas o conteúdo de cada seção ainda é genérico — a edição cuidadosa do texto, com sua experiência, suas fontes e seus exemplos, é o que vai transformar isto em um produto real e confiável.`;

  const conclusion = `Esta estrutura está pronta para ser editada. Revise cada capítulo, adicione fontes e exemplos concretos, e ajuste o tom para a voz que você quer transmitir ao leitor. Um produto digital de qualidade depende da revisão humana — use este rascunho como esqueleto, não como entrega final.`;

  const cta = `Convide o leitor a dar o próximo passo: uma lista de e-mails, uma comunidade ou um canal de contato direto para continuar a conversa após a leitura.`;

  const chapters: Chapter[] = [
    {
      title: `Capítulo 1 — Diagnóstico: onde você está em ${niche}`,
      content: `Antes de qualquer método, é preciso um diagnóstico honesto. Liste aqui os erros mais comuns que pessoas cometem em ${niche.toLowerCase()} e os sinais que indicam que algo precisa mudar. Substitua este texto por um questionário ou checklist real que ajude o leitor a se posicionar no ponto de partida.`,
    },
    {
      title: `Capítulo 2 — Fundamentos de ${focusWord}`,
      content: `Explique aqui os conceitos centrais que sustentam o restante do material. Esta seção deve responder: o que o leitor precisa entender antes de agir? Inclua definições, contexto e, sempre que possível, referências verificáveis.`,
    },
    {
      title: `Capítulo 3 — Plano de ação para ${cleanObjective.toLowerCase() || "alcançar o objetivo proposto"}`,
      content: `Detalhe o passo a passo prático: o que fazer, em que ordem, e com qual frequência. Quanto mais específico e mensurável, melhor — evite generalidades como "seja consistente" sem explicar como medir consistência.`,
    },
    {
      title: "Capítulo 4 — Erros comuns e como evitá-los",
      content: `Liste os obstáculos reais que costumam interromper o progresso nesse processo, e o que fazer em cada caso. Esta seção ganha muito valor com exemplos reais (mesmo que anonimizados) de quem já passou por isso.`,
    },
    {
      title: "Capítulo 5 — Acompanhamento e próximos passos",
      content: `Defina como o leitor deve medir progresso depois de aplicar o método, e o que fazer quando os resultados não aparecerem no ritmo esperado. Termine indicando claramente qual é o próximo passo recomendado.`,
    },
  ];

  return { title, subtitle, summary, introduction, conclusion, cta, chapters };
}

function buildResearch(niche: string, language: string): Research {
  const isEnglish = language === "Inglês";
  const avatarName = isEnglish ? "Reader persona (edit me)" : "Persona do leitor (edite-me)";

  return {
    avatar: {
      name: avatarName,
      idealAudience: `Pessoas que buscam evoluir em ${niche.toLowerCase()} e têm dificuldade em encontrar um caminho estruturado e confiável para isso.`,
      age: "Defina a faixa etária real do seu público",
      gender: "Defina com base em dados reais, se relevante",
      profession: "Liste as profissões mais comuns do seu público",
      income: "Faixa de renda estimada (apoie-se em pesquisa real, não em suposição)",
      city: "Região geográfica predominante",
      country: "Brasil",
      interests: [
        "Preencha com interesses reais identificados em pesquisas, comentários ou conversas",
        "Conteúdos que esse público já consome (canais, perfis, criadores)",
        "Hobbies e contextos de vida relevantes",
      ],
      pains: [
        `Dificuldade em encontrar um método claro para evoluir em ${niche.toLowerCase()}`,
        "Falta de tempo ou recursos para experimentar por tentativa e erro",
        "Desconfiança após experiências anteriores frustradas",
      ],
      dreams: [
        "Substitua por objetivos reais coletados diretamente do seu público",
        "Evite suposições — valide com conversas, formulários ou comentários reais",
      ],
    },
    objections: [
      "\"Isso funciona mesmo para mim?\" — responda com provas concretas, não com promessas",
      "\"Não tenho tempo.\" — mostre o esforço mínimo real necessário, sem exagerar",
      "\"Já tentei outras coisas e não deu certo.\" — explique a diferença real desta abordagem",
    ],
    toneOfVoice: "Defina o tom desejado (direto, acolhedor, técnico, bem-humorado...) e mantenha-o consistente em todo o material.",
    convertingWords: [
      "Substitua por termos que ressoam de verdade com o seu público",
      "Evite jargão de marketing genérico (\"método definitivo\", \"resultado garantido\")",
    ],
    promises: [
      "Toda promessa feita aqui precisa ser sustentável e verificável — evite exagerar resultados.",
    ],
    benefits: [
      "Liste benefícios concretos e específicos do seu produto",
      "Diferencie o que é exclusivo do seu material do que é genérico do nicho",
    ],
    arguments: [
      "Substitua por um argumento lógico real que sustente por que este método funciona, apoiado em dados, experiência ou estudos verificáveis.",
    ],
  };
}

function buildOutreachPlan(niche: string, productName: string): OutreachPlan {
  return {
    socialPosts: {
      category: "Conteúdo orgânico em redes sociais",
      channelTips: [
        "Publique conteúdo de valor sobre o tema antes de oferecer o produto — construa autoridade primeiro.",
        "Use os bastidores da criação do material como conteúdo (processo, decisões, aprendizados).",
        "Responda dúvidas reais do seu público nos comentários; elas são pauta gratuita.",
      ],
      contentIdeas: [
        `Um carrossel resumindo o "Capítulo 1" do seu material sobre ${niche.toLowerCase()}`,
        "Um vídeo curto desmistificando um erro comum do nicho",
        "Uma sequência de stories mostrando o problema que o produto resolve",
      ],
      messageTemplate: `Modelo de legenda — edite com sua voz:\n\n"Um erro comum em ${niche.toLowerCase()} é [substitua pelo erro real]. Eu reuni um passo a passo completo sobre como evitar isso em '${productName || "meu material"}'. Comenta '${"QUERO"}' que te mando o link."`,
    },
    communities: {
      category: "Comunidades e grupos temáticos",
      channelTips: [
        "Leia as regras do grupo antes de postar qualquer coisa — muitos proíbem autopromoção direta.",
        "Participe genuinamente antes de compartilhar seu material; contribua primeiro, promova depois.",
        "Prefira responder perguntas específicas com seu conteúdo como complemento, não como anúncio.",
      ],
      contentIdeas: [
        "Identifique 3 a 5 comunidades reais (não estimadas) onde seu público real participa",
        "Responda uma dúvida frequente do grupo citando um trecho do seu material como fonte",
      ],
      messageTemplate: `Modelo de resposta em comunidade — use apenas onde for permitido e relevante:\n\n"Sobre essa dúvida: [resposta real e útil]. Escrevi um material mais completo sobre isso em '${productName || "meu produto"}', caso queira se aprofundar — posso compartilhar se for do interesse do grupo."`,
    },
    directOutreach: {
      category: "Contato direto (rede pessoal)",
      channelTips: [
        "Comece pela sua rede mais próxima: pessoas que já confiam em você convertem melhor que estranhos.",
        "Peça feedback antes de pedir venda — isso abre a conversa de forma honesta.",
        "Seja transparente sobre o fato de estar lançando um produto novo.",
      ],
      contentIdeas: [
        "Liste 10 a 20 contatos que genuinamente se beneficiariam do material",
        "Envie uma mensagem pessoal pedindo feedback sincero antes do lançamento oficial",
      ],
      messageTemplate: `Modelo de mensagem direta — personalize para cada contato:\n\n"Oi [Nome], estou lançando um material sobre ${niche.toLowerCase()} chamado '${productName || "meu produto"}'. Lembrei de você porque [motivo real e específico]. Eu adoraria sua opinião sincera — posso te mandar?"`,
    },
    emailList: {
      category: "Lista de e-mail / newsletter",
      channelTips: [
        "Ofereça uma amostra gratuita (um capítulo ou checklist) em troca do e-mail.",
        "Envie uma sequência curta de 3 a 5 e-mails contando o contexto antes de vender.",
        "Sempre inclua uma forma fácil de cancelar a inscrição — isso constrói confiança.",
      ],
      contentIdeas: [
        "E-mail 1: a história ou motivação por trás do material",
        "E-mail 2: um problema comum do nicho e como pensar sobre ele",
        "E-mail 3: apresentação do produto com link de acesso",
      ],
      messageTemplate: `Modelo de assunto de e-mail — teste variações:\n\n"O erro que quase todo mundo comete em ${niche.toLowerCase()} (e como evitá-lo)"`,
    },
  };
}

export interface GenerateProjectInput {
  name: string;
  niche: string;
  objective: string;
  pages: number;
  language: string;
  coverUrl?: string;
}

/**
 * Gera a estrutura inicial de um projeto a partir das informações fornecidas.
 * Determinístico: a mesma entrada sempre produz a mesma estrutura de saída.
 * O conteúdo retornado é um rascunho editável, não um texto final.
 */
export function generateProjectDraft(input: GenerateProjectInput): Omit<
  Project,
  "id" | "createdAt" | "sales"
> {
  const name = input.name.trim() || "Novo produto digital";
  const niche = input.niche.trim() || "Desenvolvimento pessoal";
  const objective = input.objective.trim() || "Ajudar o leitor a estruturar um plano de ação prático.";
  const pages = Number(input.pages) || 30;
  const language = input.language.trim() || "Português";
  const coverUrl = pickCoverUrl(niche, input.coverUrl);

  return {
    name,
    niche,
    objective,
    pages,
    language,
    coverUrl,
    ebook: buildEbook(name, niche, objective),
    research: buildResearch(niche, language),
    outreach: buildOutreachPlan(niche, name),
    milestones: {
      // Apenas a estrutura do material foi de fato criada neste momento.
      // Os demais marcos dependem de um trabalho real do usuário (validar
      // pesquisa, personalizar mensagens, mapear comunidades, divulgar e
      // vender) e por isso começam como pendentes.
      ebookCreated: true,
      researchCompleted: false,
      messagesReady: false,
      communitiesAnalyzed: false,
      firstPromoDone: false,
      firstSaleRegistered: false,
    },
  };
}
