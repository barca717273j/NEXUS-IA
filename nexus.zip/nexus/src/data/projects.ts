import { supabase } from "../lib/supabase";
import { Project, Sale, EbookContent, Research, OutreachPlan, ProjectMilestones } from "../types";
import { GenerateProjectInput, generateProjectDraft } from "./generator";

// ----------------------------------------------------------------------------
// Camada de acesso a dados: projetos e vendas
// Converte entre o formato de linhas do Supabase (snake_case, jsonb) e os
// tipos de domínio usados pelo restante do app (camelCase).
// ----------------------------------------------------------------------------

interface ProjectRow {
  id: string;
  user_id: string;
  name: string;
  niche: string;
  objective: string;
  pages: number;
  language: string;
  cover_url: string | null;
  ebook: EbookContent;
  research: Research;
  outreach: OutreachPlan;
  milestones: ProjectMilestones;
  created_at: string;
}

interface SaleRow {
  id: string;
  user_id: string;
  project_id: string;
  value: number;
  sale_date: string;
  note: string | null;
  created_at: string;
}

function rowToSale(row: SaleRow): Sale {
  return {
    id: row.id,
    projectId: row.project_id,
    value: Number(row.value),
    date: row.sale_date,
    note: row.note ?? undefined,
  };
}

function rowToProject(row: ProjectRow, sales: Sale[]): Project {
  return {
    id: row.id,
    name: row.name,
    niche: row.niche,
    objective: row.objective,
    pages: row.pages,
    language: row.language,
    coverUrl: row.cover_url || "",
    createdAt: row.created_at,
    ebook: row.ebook,
    research: row.research,
    outreach: row.outreach,
    milestones: row.milestones,
    sales,
  };
}

export async function fetchProjects(userId: string): Promise<Project[]> {
  const [{ data: projectRows, error: projectsError }, { data: saleRows, error: salesError }] =
    await Promise.all([
      supabase
        .from("projects")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false }),
      supabase
        .from("sales")
        .select("*")
        .eq("user_id", userId)
        .order("sale_date", { ascending: false }),
    ]);

  if (projectsError) throw projectsError;
  if (salesError) throw salesError;

  const salesByProject = new Map<string, Sale[]>();
  for (const row of (saleRows || []) as SaleRow[]) {
    const sale = rowToSale(row);
    const list = salesByProject.get(sale.projectId) || [];
    list.push(sale);
    salesByProject.set(sale.projectId, list);
  }

  return ((projectRows || []) as ProjectRow[]).map((row) =>
    rowToProject(row, salesByProject.get(row.id) || [])
  );
}

export async function createProject(
  userId: string,
  input: GenerateProjectInput
): Promise<Project> {
  const draft = generateProjectDraft(input);

  const { data, error } = await supabase
    .from("projects")
    .insert({
      user_id: userId,
      name: draft.name,
      niche: draft.niche,
      objective: draft.objective,
      pages: draft.pages,
      language: draft.language,
      cover_url: draft.coverUrl,
      ebook: draft.ebook,
      research: draft.research,
      outreach: draft.outreach,
      milestones: draft.milestones,
    })
    .select("*")
    .single();

  if (error) throw error;
  return rowToProject(data as ProjectRow, []);
}

export async function updateProjectMilestones(
  projectId: string,
  milestones: ProjectMilestones
): Promise<void> {
  const { error } = await supabase
    .from("projects")
    .update({ milestones })
    .eq("id", projectId);

  if (error) throw error;
}

export async function deleteProject(projectId: string): Promise<void> {
  const { error } = await supabase.from("projects").delete().eq("id", projectId);
  if (error) throw error;
}

export async function registerSale(
  userId: string,
  projectId: string,
  sale: { value: number; date: string; note?: string },
  currentMilestones: ProjectMilestones
): Promise<Sale> {
  const { data, error } = await supabase
    .from("sales")
    .insert({
      user_id: userId,
      project_id: projectId,
      value: sale.value,
      sale_date: sale.date,
      note: sale.note || null,
    })
    .select("*")
    .single();

  if (error) throw error;

  // Marca o marco de "primeira venda" automaticamente, preservando os demais marcos.
  if (!currentMilestones.firstSaleRegistered) {
    await supabase
      .from("projects")
      .update({ milestones: { ...currentMilestones, firstSaleRegistered: true } })
      .eq("id", projectId);
  }

  return rowToSale(data as SaleRow);
}

export async function deleteSale(saleId: string): Promise<void> {
  const { error } = await supabase.from("sales").delete().eq("id", saleId);
  if (error) throw error;
}
