import { jsPDF } from "jspdf";
import { Project } from "../types";

// ----------------------------------------------------------------------------
// Exportação real de PDF
// ----------------------------------------------------------------------------
// Gera um arquivo .pdf de verdade no navegador, com texto selecionável e
// paginação automática — diferente de simplesmente abrir o diálogo de
// impressão do navegador (que depende da configuração de cada impressora
// e não gera um arquivo).
// ----------------------------------------------------------------------------

const PAGE_WIDTH = 210; // A4 em mm
const PAGE_HEIGHT = 297;
const MARGIN = 22;
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2;

export function exportProjectToPdf(project: Project): void {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  let y = MARGIN;

  function ensureSpace(neededHeight: number) {
    if (y + neededHeight > PAGE_HEIGHT - MARGIN) {
      doc.addPage();
      y = MARGIN;
    }
  }

  function writeHeading(text: string, size = 18) {
    ensureSpace(size / 2 + 6);
    doc.setFont("times", "bold");
    doc.setFontSize(size);
    doc.setTextColor(20, 20, 20);
    const lines = doc.splitTextToSize(text, CONTENT_WIDTH);
    doc.text(lines, MARGIN, y);
    y += lines.length * (size / 2.6) + 4;
  }

  function writeBody(text: string, size = 10.5) {
    doc.setFont("times", "normal");
    doc.setFontSize(size);
    doc.setTextColor(40, 40, 40);
    const lines = doc.splitTextToSize(text, CONTENT_WIDTH);
    const lineHeight = size / 2.4;
    for (const line of lines) {
      ensureSpace(lineHeight);
      doc.text(line, MARGIN, y);
      y += lineHeight;
    }
    y += 4;
  }

  function writeDivider() {
    ensureSpace(6);
    doc.setDrawColor(176, 33, 47);
    doc.setLineWidth(0.4);
    doc.line(MARGIN, y, MARGIN + 18, y);
    y += 8;
  }

  // Capa
  doc.setFont("times", "bold");
  doc.setFontSize(26);
  doc.setTextColor(20, 20, 20);
  const titleLines = doc.splitTextToSize(project.ebook.title, CONTENT_WIDTH);
  y = PAGE_HEIGHT / 2 - (titleLines.length * 11) / 2 - 14;
  doc.text(titleLines, PAGE_WIDTH / 2, y, { align: "center" });
  y += titleLines.length * 11 + 8;

  doc.setFont("times", "italic");
  doc.setFontSize(12);
  doc.setTextColor(90, 90, 90);
  const subtitleLines = doc.splitTextToSize(project.ebook.subtitle, CONTENT_WIDTH - 20);
  doc.text(subtitleLines, PAGE_WIDTH / 2, y, { align: "center" });

  // Introdução
  doc.addPage();
  y = MARGIN;
  writeHeading("Introdução");
  writeDivider();
  writeBody(project.ebook.introduction);

  // Resumo
  ensureSpace(14);
  writeHeading("Resumo", 14);
  writeBody(project.ebook.summary);

  // Capítulos
  for (const chapter of project.ebook.chapters) {
    doc.addPage();
    y = MARGIN;
    writeHeading(chapter.title, 16);
    writeDivider();
    writeBody(chapter.content);
  }

  // Conclusão + CTA
  doc.addPage();
  y = MARGIN;
  writeHeading("Conclusão");
  writeDivider();
  writeBody(project.ebook.conclusion);
  ensureSpace(14);
  writeHeading("Próximo passo", 13);
  writeBody(project.ebook.cta);

  const safeName = project.ebook.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase().slice(0, 60);
  doc.save(`${safeName || "ebook"}.pdf`);
}
