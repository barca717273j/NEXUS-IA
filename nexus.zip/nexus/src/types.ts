// ----------------------------------------------------------------------------
// Tipos de domínio do NEXUS
// ----------------------------------------------------------------------------

export interface Chapter {
  title: string;
  content: string;
}

export interface EbookContent {
  title: string;
  subtitle: string;
  summary: string;
  introduction: string;
  conclusion: string;
  cta: string;
  chapters: Chapter[];
}

export interface Avatar {
  name: string;
  idealAudience: string;
  age: string;
  gender: string;
  profession: string;
  income: string;
  city: string;
  country: string;
  interests: string[];
  pains: string[];
  dreams: string[];
}

export interface Research {
  avatar: Avatar;
  objections: string[];
  toneOfVoice: string;
  convertingWords: string[];
  promises: string[];
  benefits: string[];
  arguments: string[];
}

export interface OutreachChannel {
  category: string;
  channelTips: string[];
  contentIdeas: string[];
  messageTemplate: string;
}

export interface OutreachPlan {
  socialPosts: OutreachChannel;
  communities: OutreachChannel;
  directOutreach: OutreachChannel;
  emailList: OutreachChannel;
}

export interface ProjectMilestones {
  ebookCreated: boolean;
  researchCompleted: boolean;
  messagesReady: boolean;
  communitiesAnalyzed: boolean;
  firstPromoDone: boolean;
  firstSaleRegistered: boolean;
}

export interface Sale {
  id: string;
  projectId: string;
  value: number;
  date: string;
  note?: string;
}

export interface Project {
  id: string;
  name: string;
  niche: string;
  objective: string;
  pages: number;
  language: string;
  coverUrl: string;
  createdAt: string;
  ebook: EbookContent;
  research: Research;
  outreach: OutreachPlan;
  milestones: ProjectMilestones;
  sales: Sale[];
}

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  monthlyGoal: number;
}
