import { useState, useEffect, useCallback } from "react";
import { AnimatePresence } from "framer-motion";
import { Briefcase, LayoutGrid } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import ProjectWizard from "./components/ProjectWizard";
import ProjectTabs from "./components/ProjectTabs";
import SalesLedger from "./components/SalesLedger";
import SettingsPanel from "./components/SettingsPanel";
import Auth from "./components/Auth";
import SetupNotice from "./components/SetupNotice";
import { useAuth } from "./hooks/useAuth";
import { isSupabaseConfigured } from "./lib/supabase";
import { Project, ProjectMilestones } from "./types";
import * as projectsApi from "./data/projects";

type ActiveTab = "dashboard" | "new-project" | "library" | "sales-ledger" | "settings";

export default function App() {
  if (!isSupabaseConfigured) {
    return <SetupNotice />;
  }
  return <AuthenticatedApp />;
}

function AuthenticatedApp() {
  const { user, profile, loading: authLoading, signOut, updateMonthlyGoal } = useAuth();

  const [projects, setProjects] = useState<Project[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");
  const [isCreating, setIsCreating] = useState(false);

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [viewMode, setViewMode] = useState<"desktop" | "mobile">("desktop");
  const [isActualMobile, setIsActualMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => setIsActualMobile(window.innerWidth < 768);
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const isMobileView = viewMode === "mobile" || isActualMobile;

  useEffect(() => {
    setSidebarCollapsed(isMobileView);
  }, [isMobileView]);

  const loadProjects = useCallback(async (userId: string) => {
    setProjectsLoading(true);
    try {
      const data = await projectsApi.fetchProjects(userId);
      setProjects(data);
      setSelectedProjectId((prev) => prev || data[0]?.id || "");
    } catch (err) {
      console.error("Falha ao carregar projetos:", err);
    } finally {
      setProjectsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) {
      loadProjects(user.id);
    } else {
      setProjects([]);
      setSelectedProjectId("");
    }
  }, [user, loadProjects]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-0">
        <p className="text-sm text-text-muted">Carregando...</p>
      </div>
    );
  }

  if (!user || !profile) {
    return <Auth />;
  }

  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const handleCreateProject = async (
    name: string,
    niche: string,
    objective: string,
    pages: number,
    language: string,
    coverUrl?: string
  ) => {
    setIsCreating(true);
    try {
      const newProject = await projectsApi.createProject(user.id, {
        name,
        niche,
        objective,
        pages,
        language,
        coverUrl,
      });
      setProjects((prev) => [newProject, ...prev]);
      setSelectedProjectId(newProject.id);
      setActiveTab("library");
    } catch (err) {
      console.error("Falha ao criar projeto:", err);
      alert("Não foi possível criar o projeto. Verifique sua conexão e tente novamente.");
    } finally {
      setIsCreating(false);
    }
  };

  const handleToggleMilestone = async (key: keyof ProjectMilestones) => {
    if (!activeProject) return;
    const updated = { ...activeProject.milestones, [key]: !activeProject.milestones[key] };
    setProjects((prev) => prev.map((p) => (p.id === activeProject.id ? { ...p, milestones: updated } : p)));
    try {
      await projectsApi.updateProjectMilestones(activeProject.id, updated);
    } catch (err) {
      console.error("Falha ao atualizar plano de execução:", err);
    }
  };

  const handleRegisterSaleForActiveProject = async (sale: { value: number; date: string; note?: string }) => {
    if (!activeProject) return;
    await handleRegisterSale(activeProject.id, sale);
  };

  const handleRegisterSale = async (
    projectId: string,
    sale: { value: number; date: string; note?: string }
  ) => {
    const project = projects.find((p) => p.id === projectId);
    if (!project) return;
    try {
      const newSale = await projectsApi.registerSale(user.id, projectId, sale, project.milestones);
      setProjects((prev) =>
        prev.map((p) =>
          p.id === projectId
            ? {
                ...p,
                sales: [newSale, ...p.sales],
                milestones: { ...p.milestones, firstSaleRegistered: true },
              }
            : p
        )
      );
    } catch (err) {
      console.error("Falha ao registrar venda:", err);
      alert("Não foi possível registrar a venda. Tente novamente.");
    }
  };

  const handleDeleteSale = async (saleId: string) => {
    if (!activeProject) return;
    try {
      await projectsApi.deleteSale(saleId);
      setProjects((prev) =>
        prev.map((p) =>
          p.id === activeProject.id ? { ...p, sales: p.sales.filter((s) => s.id !== saleId) } : p
        )
      );
    } catch (err) {
      console.error("Falha ao remover venda:", err);
    }
  };

  const handleDeleteAllProjects = async () => {
    try {
      await Promise.all(projects.map((p) => projectsApi.deleteProject(p.id)));
      setProjects([]);
      setSelectedProjectId("");
      setActiveTab("dashboard");
    } catch (err) {
      console.error("Falha ao excluir projetos:", err);
    }
  };

  const renderWorkspace = () => (
    <div className="flex-1 flex flex-row relative w-full h-full min-h-screen overflow-x-hidden">
      {isMobileView && !sidebarCollapsed && (
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-[35] cursor-pointer"
          onClick={() => setSidebarCollapsed(true)}
        />
      )}

      {isMobileView && sidebarCollapsed && (
        <button
          onClick={() => setSidebarCollapsed(false)}
          className="absolute left-4 top-[88px] z-40 flex items-center justify-center w-10 h-10 rounded-xl bg-brand text-white cursor-pointer shadow-lg transition-transform hover:scale-105 active:scale-95"
          title="Abrir menu"
        >
          <LayoutGrid size={17} />
        </button>
      )}

      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab as ActiveTab);
          if (isMobileView) setSidebarCollapsed(true);
        }}
        onLogout={signOut}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        hasActiveProject={projects.length > 0}
        userName={profile.fullName || profile.email}
        isMobileView={isMobileView}
      />

      <div
        className={`flex-1 flex flex-col transition-all duration-300 min-h-screen overflow-x-hidden max-w-full ${
          isMobileView ? "pl-0" : sidebarCollapsed ? "pl-[76px]" : "pl-0 md:pl-[260px]"
        }`}
      >
        <Header
          userName={profile.fullName || profile.email}
          userEmail={profile.email}
          onOpenSettings={() => setActiveTab("settings")}
          onLogout={signOut}
          viewMode={viewMode}
          setViewMode={setViewMode}
        />

        <main className="flex-1 p-6 md:p-8 space-y-8 overflow-x-hidden">
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && (
              <Dashboard
                key="dashboard"
                projects={projects}
                monthlyGoal={profile.monthlyGoal}
                onCreateNew={() => setActiveTab("new-project")}
                onSelectProject={(id) => {
                  setSelectedProjectId(id);
                  setActiveTab("library");
                }}
              />
            )}

            {activeTab === "new-project" && (
              <ProjectWizard key="new-project" onGenerate={handleCreateProject} isSubmitting={isCreating} />
            )}

            {activeTab === "library" &&
              (activeProject ? (
                <ProjectTabs
                  key={activeProject.id}
                  project={activeProject}
                  onToggleMilestone={handleToggleMilestone}
                  onRegisterSale={handleRegisterSaleForActiveProject}
                  onDeleteSale={handleDeleteSale}
                />
              ) : (
                <div className="text-center py-16 bg-surface-1 border border-border rounded-2xl">
                  <Briefcase size={32} className="text-text-muted mx-auto mb-4" />
                  <h3 className="text-sm font-medium text-text-secondary">Nenhum projeto ainda</h3>
                  <p className="text-xs text-text-muted mt-1">Crie um novo projeto para começar.</p>
                </div>
              ))}

            {activeTab === "sales-ledger" && (
              <SalesLedger key="sales-ledger" projects={projects} onRegisterSale={handleRegisterSale} />
            )}

            {activeTab === "settings" && (
              <SettingsPanel
                key="settings"
                profile={profile}
                onUpdateGoal={updateMonthlyGoal}
                onDeleteAllProjects={handleDeleteAllProjects}
              />
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );

  if (projectsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-0">
        <p className="text-sm text-text-muted">Carregando seus projetos...</p>
      </div>
    );
  }

  if (viewMode === "mobile" && !isActualMobile) {
    return (
      <div className="min-h-screen bg-surface-0 flex flex-col items-center justify-center antialiased relative">
        <div className="w-[385px] h-screen border-x border-border bg-surface-0 flex flex-col relative shadow-2xl">
          <div className="bg-surface-1 px-5 py-2.5 border-b border-border flex items-center justify-between text-xs font-mono text-text-muted shrink-0">
            <span>Pré-visualização — celular</span>
            <span>385px</span>
          </div>
          <div className="flex-1 h-full flex flex-col overflow-y-auto overflow-x-hidden relative">
            {renderWorkspace()}
          </div>
        </div>
      </div>
    );
  }

  return <div className="min-h-screen bg-surface-0 text-text-primary flex font-sans antialiased">{renderWorkspace()}</div>;
}
